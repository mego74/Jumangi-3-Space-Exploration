﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AmmoCrate : MonoBehaviour
{
    [Header("Gameplay")]
    public int ammo = 12;
public GameObject container;
    
    void Update()
    {
    
    }
}
